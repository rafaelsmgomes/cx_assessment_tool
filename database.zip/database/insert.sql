INSERT INTO users (
    user_name, 
    size, 
    industry, 
    number_employees, 
    country
) VALUES (
    
);


INSERT INTO answers (
    user_id, 
    question_id, 
    ans_value, 
    ans_text
) VALUES (
    1, 
    0, 
    69, 
    NULL
);

INSERT INTO answers (
    user_id, 
    question_id, 
    ans_value, 
    ans_text
) VALUES (2, 3, 75, Something, Something), (2, 0, 55, Other stuff, multiple stuff, various answers);